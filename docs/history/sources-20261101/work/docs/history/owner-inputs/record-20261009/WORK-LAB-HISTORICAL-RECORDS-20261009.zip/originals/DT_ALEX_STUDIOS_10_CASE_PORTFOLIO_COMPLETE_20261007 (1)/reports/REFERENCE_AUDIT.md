# Reference audit — 2026-10-07

## Unseen Studio

Reviewed `https://unseen.co/projects/` and the Cult of the North detail page. The projects index communicates drag-to-explore discovery, category filters, a selected-project sequence and a clear path to the work. The detail page pairs a concise project overview and service metadata with a long visual sequence, a focused brief, a distinct interaction idea, technical context and a next-project transition. This portfolio borrows those editorial principles and pacing only. It does not reproduce the studio's identity, copy, artwork, code, shader, or page composition.

## Additional public visual references located

- Behance, “Visual Identity, Editorial Design — Hi On Life” (Sakaria Studio): search-result metadata showed 10.4K appreciations; used only as a signal that a single project can tell a coherent identity story across editorial and exhibition touchpoints. https://www.behance.net/gallery/61580857/Visual-Identity-Editorial-Design-Hi-On-Life
- Behance, “BMD Creative Studio — Branding Case Study” (Jasleen Ashta): 1.3K appreciations in result metadata; useful for an ordered identity case structure (logo, construction, type, pattern, applications, website). https://www.behance.net/gallery/119380191/BMD-Creative-Studio-Branding-Case-Study
- Awwwards, “The Brand Identity”: an Honorable Mention page with project screenshots, mobile/desktop elements, palette and individual judge scores; useful as a quality-review reference. https://www.awwwards.com/sites/the-brand-identity
- Awwwards case-study archive: current examples show a range of case-story approaches across digital, brand and motion. https://www.awwwards.com/blog/?tag=case-study&text=ux-design

These references informed case-study structure and quality criteria; no third-party image assets were copied into the deliverable. New visuals in the case pack were generated specifically for this portfolio prototype.

## Evidence limits

The Unseen detail page's text and section order were retrievable. Its automated browser screenshot initially displayed the site's loading layer, so this report does not claim full screenshot capture of every animation or project section. Behance/Awwwards search-result counts and page labels are time-sensitive and are used only as research provenance, not as performance promises.

## Screenshot review note

The Unseen page was inspected in the browser and its accessible project-detail structure was reviewed. Its page-level loading overlay stayed visible during the captured browser view, so no usable screenshot slice was extracted from that site. Research examples are cited by their public project pages instead; the generated case artwork in this package is original to this task.

Additional curated references:
- Lahti International Poster Triennial 2025, official exhibition page and poster selection: https://www.malvamuseo.fi/en/lahti-international-poster-triennial/poster-triennial-2025/
- AIGA Baltimore Flux 2024 winners archive, including the “Dream: Moments Unmaking” Best in Show entry: https://2024.fluxdesigncompetition.org/winners.php
- ECNU “Eyes Wide Open” 20th anniversary campaign, Behance project page; the search result identifies a Red Dot Award 2025 mark: https://www.behance.net/gallery/242028819/Eyes-Wide-Open
