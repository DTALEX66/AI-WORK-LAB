# Generated image asset map

All 30 images in `public/assets/cases/` were generated specifically for this portfolio. Each case includes a landscape hero and two distinct supporting visuals. The website overlays exact titles and case copy in HTML. Images contain no intended readable copy, logos, or watermarks.

| Case | Hero | Supporting artwork 1 | Supporting artwork 2 |
|---|---|---|---|
| ArcheAxis Knowledge | `aaos-hero.webp` — cool orbital knowledge archive | `aaos-source.webp` — linked source archive and evidence cards | `aaos-learning.webp` — reading, citation, and learning workspace |
| WORK-LAB | `worklab-hero.webp` — agent orchestration control plane | `worklab-workflow.webp` — workflow lanes and approval checkpoint | `worklab-audit.webp` — execution trace and audit view |
| DESIGN-LAB | `designlab-hero.webp` — research and design-production board | `designlab-research.webp` — creative research canvas | `designlab-preflight.webp` — preflight checklist and export review |
| NOCTURNE | `nocturne-hero.webp` — dark fragrance bottle and mineral box | `nocturne-material.webp` — glass, silver, and stone macro | `nocturne-packaging.webp` — bottle and packaging still life |
| FIELD INDEX | `field-index-hero.webp` — botanical editorial cover | `field-index-spread.webp` — specimen-led book spread | `field-index-map.webp` — urban botanical field map |
| TIDELINE | `tideline-hero.webp` — ocean conservation visual | `tideline-poster-detail.webp` — close wave and fish graphic | `tideline-campaign.webp` — three-poster exhibition view |
| KINETIC FIELD | `kinetic-field-hero.webp` — typographic motion key visual | `kinetic-storyboard.webp` — timing and motion sequence board | `kinetic-frame.webp` — blue/citron impact frame |
| FORM STUDY 06 | `form-study-hero.webp` — folded metal and cobalt chair | `form-study-detail.webp` — three-quarter furniture render | `form-study-material.webp` — metal fold and seat detail |
| AFTER HOURS | `after-hours-hero.webp` — night arts key visual | `after-hours-posters.webp` — poster, ticket, and campaign family | `after-hours-screen.webp` — luminous city gallery scene |
| COMMON GROUND | `common-ground-hero.webp` — public exhibition interior | `common-ground-wayfinding.webp` — accessible sign and route system | `common-ground-material.webp` — exhibition identity in space |

Image direction: original assets with 16:9 compositions, tailored palettes and materials, no copied imagery or named-brand imitation. The first three projects use portfolio-built HTML interface visualizations alongside generated artwork; these are not live product screenshots.
