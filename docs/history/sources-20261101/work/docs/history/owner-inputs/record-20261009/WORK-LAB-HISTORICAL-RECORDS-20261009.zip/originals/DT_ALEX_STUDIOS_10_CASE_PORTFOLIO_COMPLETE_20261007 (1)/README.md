# DT ALEX STUDIOS — Complete 10 Case Portfolio

A responsive, static portfolio website with ten complete case studies. Every case has a hero banner, two distinct supporting images, original case copy, and its own responsive detail page. No image slots are left empty.

## Open the website

Open `index.html` in a modern browser, or serve this directory over HTTP:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`. Select any case from the home grid. Individual pages use `?case=<slug>`, for example `?case=aaos`.

## Included

- `index.html`, `app.js`, `styles.css` — complete responsive portfolio.
- `public/assets/cases/` — 30 optimized WebP artworks: 10 hero banners and 20 unique detail images.
- `public/favicon.svg` — portfolio mark.
- `reports/CASE_COPY.md` — copy plan and full case narratives.
- `reports/ASSET_PROMPTS.md` — asset inventory and visual direction.
- `reports/REFERENCE_AUDIT.md` — design research and reference boundaries.
- `reports/QA.md` — validation record.

## Project status

ArcheAxis Knowledge, WORK-LAB and DESIGN-LAB are ongoing personal projects described from the supplied plans. The product interfaces are portfolio visualizations; they do not claim to be live product screenshots or production receipts. Seven other entries are complete self-initiated fictional concept projects and are labeled as such.

## Visual reference

The detail-page rhythm takes inspiration from Unseen Studio's project storytelling, metadata and visual sequencing. Additional public references informed case-study structure and visual review. No third-party images, copy, source code, logo or brand assets are included.
