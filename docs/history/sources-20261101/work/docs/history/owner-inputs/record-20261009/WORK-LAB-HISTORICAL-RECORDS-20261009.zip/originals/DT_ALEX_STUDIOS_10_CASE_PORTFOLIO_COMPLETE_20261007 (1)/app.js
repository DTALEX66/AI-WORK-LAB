const projects = [
  {
    id:'aaos', number:'01', title:'ArcheAxis Knowledge', titleCN:'星环知识平台', type:'PERSONAL / DIGITAL', disciplines:['Product Design','Knowledge System','Visual Design'], year:'2026 — Ongoing', status:'Ongoing · Personal system', image:'public/assets/cases/aaos-hero.webp', gallery:['public/assets/cases/aaos-source.webp','public/assets/cases/aaos-learning.webp'], accent:'#77d9d1',
    summary:'本地优先、可追溯的个人知识工作台，让原始资料、个人思考与学习过程持续连在一起。',
    brief:'资料、研究、对话和自己的判断散落在不同工具里，时间一久，来源难以找回，学习也很难接着上次继续。',
    approach:'我把它设计成长期使用的知识工作台。普通内容可以先保存、检索与编辑；来源忠实度核验和专业依据分析分别呈现。学习与机器反馈保持可追溯，候选不会自动成为可信事实。',
    system:'围绕工作台、知识、学习、AI 学习、探索与系统能力组织入口。阅读和编辑是主场景，证据锚点、版本、引用与学习事件按需展开。当前规划采用 Tauri 2、React/TypeScript/Vite 与 Rust Core，SQLite/CAS 保持权威数据边界。',
    next:'持续推进本地内容闭环、可靠保存与恢复、多格式识别、搜索和人机双向学习；未来能力保持可发现，并按前置条件逐步开放。',
    visuals:['原件与来源','阅读 / 编辑','人机学习','空间关系'],
    ui:{kind:'aaos',label:'KNOWLEDGE WORKSPACE',sub:'阅读 · 来源 · 学习'}
  },
  {
    id:'worklab', number:'02', title:'WORK-LAB', titleCN:'工作流实验室', type:'PERSONAL / DIGITAL', disciplines:['Product Design','Agent Systems','Observability'], year:'2026 — Ongoing', status:'Ongoing · Personal system', image:'public/assets/cases/worklab-hero.webp', gallery:['public/assets/cases/worklab-workflow.webp','public/assets/cases/worklab-audit.webp'], accent:'#5ca8ff',
    summary:'客户端中立的 AI Agent 控制平面，把规则、技能与工作流治理收敛到一个规范源。',
    brief:'不同 Agent 客户端各自维护规则、技能和记忆，能力容易漂移；从计划到执行、审计和交付也缺少统一视角。',
    approach:'我把 WORK-LAB 定义为控制与治理层。规范源负责描述，适配层按客户端原生方式投影；任务包串起目标、执行、审批、审计与交付，让每一步都有可检查的边界。',
    system:'产品视图围绕任务、工作流、执行、Observer、规则策略、集成与审批组织。Observer 只读呈现状态；缺少的数据明确显示 UNKNOWN。高风险外部变更需要独立确认。',
    next:'继续完善审批回路、失败恢复与发布门禁，并通过明确的 Adapter 契约接入新的客户端。页面里的状态仅作作品集演示，不代替实时系统回执。',
    visuals:['控制平面','工作流编排','只读观察','审计与交付'],
    ui:{kind:'worklab',label:'EXECUTION CONTROL',sub:'任务 · 策略 · 交付'}
  },
  {
    id:'designlab', number:'03', title:'DESIGN-LAB', titleCN:'视觉设计实验室', type:'PERSONAL / DIGITAL', disciplines:['Design Intelligence','Creative Production','Quality'], year:'2026 — Ongoing', status:'Ongoing · Personal system', image:'public/assets/cases/designlab-hero.webp', gallery:['public/assets/cases/designlab-research.webp','public/assets/cases/designlab-preflight.webp'], accent:'#7ca7ff',
    summary:'AI 原生、平台中立的设计生产系统，把研究、设计方法、质量预检与交付连成可回溯流程。',
    brief:'参考、生成、排版、修改和导出分布在不同工具中。做过什么判断、为什么选这个方向，常常没能跟作品一起留下来。',
    approach:'我把设计工作组织成 Research / Evidence → Brief → Direction → DesignSystem → 生产 → Preflight → 交付。版本链保留设计决定；预检只探测并报告，不暗中安装或改变环境。',
    system:'工作台覆盖项目、研究、品牌系统、设计领域、工具适配、质量预检与交付。它连接宿主工具，不重建画布、聊天客户端、模型网关或 SaaS 后端。证据级别 E0–E5 分开表达。',
    next:'细化交付前检查规则，并按真实需要扩展宿主适配器。作品集中的界面是规划视觉演示，实际接线状态以后端和仓库审计为准。',
    visuals:['Brief → Direction','Design System','Preflight QA','交付证据'],
    ui:{kind:'designlab',label:'DESIGN PRODUCTION',sub:'研究 · 创作 · 预检'}
  },
  {
    id:'nocturne', number:'04', title:'NOCTURNE', titleCN:'气味的留白', type:'CONCEPT PROJECT / BRAND', disciplines:['Brand Identity','Packaging','Art Direction'], year:'2026 · Concept', status:'Original concept · Self-initiated', image:'public/assets/cases/nocturne-hero.webp', gallery:['public/assets/cases/nocturne-material.webp','public/assets/cases/nocturne-packaging.webp'], accent:'#c6cad8',
    summary:'为一款虚构的独立香氛构想品牌识别与包装，以矿物质感和冷静留白表达夜色。',
    brief:'概念命题：让香气不靠繁复叙事取胜，而像夜间空气一样，靠材质、比例和细节慢慢显现。',
    approach:'以烟熏玻璃、岩面和银色弧线建立主视觉母题。瓶身比例保持克制，包装结构强调触感与留白，延展到静物摄影和数字橱窗。',
    system:'识别围绕低光、矿物、弧线与呼吸展开。烟熏瓶身承接暗部，银色瓶盖成为唯一高光；包装使用压纹矿物纸与克制的香型编码。静物广告、电商首屏和包装细节共享同一组低照度材质语言。',
    next:'本概念以一支夜间木质香调为创作命题，已经形成瓶器、纸盒、材质语言与主视觉的一套完整表达。',
    visuals:['瓶器与包装','材质板','包装细节','数字橱窗'], concept:true
  },
  {
    id:'field-index', number:'05', title:'FIELD INDEX', titleCN:'城市植物档案', type:'CONCEPT PROJECT / EDITORIAL', disciplines:['Editorial Design','Publication','Photography'], year:'2026 · Concept', status:'Original concept · Self-initiated', image:'public/assets/cases/field-index-hero.webp', gallery:['public/assets/cases/field-index-spread.webp','public/assets/cases/field-index-map.webp'], accent:'#9eb76d',
    summary:'一份关于城市植物如何适应环境的虚构出版物，用田野记录转译成可阅读的视觉档案。',
    brief:'概念命题：植物如何在城市缝隙里生长？如何让观察、地图和图像在纸上形成一条阅读路径？',
    approach:'采用编号、网格、局部放大的叶片纹理和地图切片作为编辑线索。跨页留出安静段落，让资料页、图像页与短叙事交替出现。',
    system:'出版物由植物观察、城市步行路线与图像索引组成。封面以叶脉切片建立辨识度，内页用跨页标本图建立停留点，地图将采样编号重新放回街区路径。线上索引沿用同一编号和色彩规则。',
    next:'这份概念刊物围绕“城市植物如何寻找生长缝隙”展开，已构成封面、图像跨页、采样地图与数字索引的一套编辑系统。',
    visuals:['封面 / 跨页','图像档案','地图系统','线上索引'], concept:true
  },
  {
    id:'tideline', number:'06', title:'TIDELINE', titleCN:'潮汐仍在', type:'CONCEPT PROJECT / POSTER', disciplines:['Graphic Design','Poster','Campaign'], year:'2026 · Concept', status:'Original concept · Self-initiated', image:'public/assets/cases/tideline-hero.webp', gallery:['public/assets/cases/tideline-poster-detail.webp','public/assets/cases/tideline-campaign.webp'], accent:'#55c9ed',
    summary:'一组虚构的海洋保护主题海报，以三张画面拼合潮流与鱼形的视觉隐喻。',
    brief:'概念命题：海洋里的安全感如何被一点一点侵蚀？一组海报如何在单张与整体之间切换阅读？',
    approach:'以断裂的水纹构成跨幅主图形，局部加入信号红作为警觉点。标题与信息区采用稳定网格，保证系列一致，也让每张独立成立。',
    system:'三张海报分别表现涨潮、回流与海面静止，单张有独立张力，连续陈列时鱼形在画面之间完成移动。数字传播裁切保留主图与行动提示；展览墙面按阅读顺序布置，建立从视觉隐喻到海洋保护主题的理解路径。',
    next:'本组原创概念以海洋保护为主题，已形成三联海报、单张细节与系列传播画面；展陈方案延续了同一套潮流图形。',
    visuals:['三联海报','单张构图','活动长图','展览呈现'], concept:true
  },
  {
    id:'kinetic-field', number:'07', title:'KINETIC FIELD', titleCN:'字形运动研究', type:'CONCEPT PROJECT / MOTION', disciplines:['Motion Design','Typography','Creative Coding'], year:'2026 · Concept', status:'Original concept · Self-initiated', image:'public/assets/cases/kinetic-field-hero.webp', gallery:['public/assets/cases/kinetic-storyboard.webp','public/assets/cases/kinetic-frame.webp'], accent:'#d6ea36',
    summary:'一组自拟动态字形实验，把网格中的字形当作具有重量、速度與阻力的物体。',
    brief:'概念命题：如果字不是贴在画面上的信息，而是受力、碰撞、停顿和释放的对象，阅读节奏会怎样变化？',
    approach:'建立固定基线与边距，使用有限色彩区分运动层级。动势由加速、碰撞和回弹组成，静帧仍保留清晰层级。',
    system:'视觉规则固定基线、边距与两种高亮色，运动由加速、碰撞、回弹和归位四个节拍组成。分镜将动作拆为可读的阶段，主视觉抽取碰撞瞬间，静帧仍保持明确的重心与方向。',
    next:'这套动态视觉练习以几何字形为主角，包含规则板、动作分镜与关键帧，可独立作为一组动态图形研究呈现。',
    visuals:['关键帧','字形规则','节奏分镜','循环预览'], concept:true
  },
  {
    id:'form-study', number:'08', title:'FORM STUDY 06', titleCN:'折面坐具', type:'CONCEPT PROJECT / 3D', disciplines:['3D Visualization','Product Concept','Material Study'], year:'2026 · Concept', status:'Original concept · Self-initiated', image:'public/assets/cases/form-study-hero.webp', gallery:['public/assets/cases/form-study-detail.webp','public/assets/cases/form-study-material.webp'], accent:'#a4c7f0',
    summary:'一个虚构的家具产品概念，以连续折面、冷金属和深蓝半透明材质探索轻量感。',
    brief:'概念命题：通过单一材料的连续弯折，构成稳定坐面与支撑关系，同时保留视觉上的轻盈。',
    approach:'以三分之四视角建立主渲染，配合材料近景、轮廓线和构造拆解图，减少无关装饰，让结构成为主角。',
    system:'主视觉展示整体姿态，材质近景强调金属折边与半透明钴蓝坐面，构造视图说明连续折面如何连接座面和支撑。冷灰棚拍让轮廓成为焦点；本案例表达产品概念，不宣称工程验证或量产。',
    next:'这一产品概念已形成主渲染、材料细节与结构表达。它聚焦于折面如何同时承担支撑和视觉轻盈感。',
    visuals:['主渲染','材质细节','结构视图','空间陈列'], concept:true
  },
  {
    id:'after-hours', number:'09', title:'AFTER HOURS', titleCN:'夜行文化计划', type:'CONCEPT PROJECT / CAMPAIGN', disciplines:['Campaign','Key Visual','Art Direction'], year:'2026 · Concept', status:'Original concept · Self-initiated', image:'public/assets/cases/after-hours-hero.webp', gallery:['public/assets/cases/after-hours-posters.webp','public/assets/cases/after-hours-screen.webp'], accent:'#ef625b',
    summary:'为虚构的夜间艺术节构想一套主视觉与延展物料，用城市光带串联不同的观看场景。',
    brief:'概念命题：夜晚不只是活动时间，它也能成为城市里另一种共同生活的空间。',
    approach:'以冷色光带、城市廊道和竖向画幅构成主视觉。红色作为少量节奏标记，延展到海报、社交传播与现场导视。',
    system:'夜间建筑照片和流动光带构成主 KV；红色几何作为节目切换标记。系列海报使用统一的网格和标题区，票面把路线线索延伸到移动端，现场屏幕则以高对比动画维持远距离可读性。',
    next:'虚构艺术节的视觉系统已覆盖主 KV、系列海报、票面与现场画面，核心线索是夜间城市中的一条发光路径。',
    visuals:['主 KV','系列海报','节目单','现场屏幕'], concept:true
  },
  {
    id:'common-ground', number:'10', title:'COMMON GROUND', titleCN:'共同场域', type:'CONCEPT PROJECT / SPATIAL', disciplines:['Spatial Graphics','Exhibition Identity','Wayfinding'], year:'2026 · Concept', status:'Original concept · Self-initiated', image:'public/assets/cases/common-ground-hero.webp', gallery:['public/assets/cases/common-ground-wayfinding.webp','public/assets/cases/common-ground-material.webp'], accent:'#a6c954',
    summary:'一场虚构的城市公共空间展览，以路径、节点和共享区域构建空间识别系统。',
    brief:'概念命题：展览如何让人从“经过空间”转为“参与空间”，并在建筑内自然找到方向？',
    approach:'将地面色带、墙面几何和模块化展具作为同一套导视语言。颜色区分路径层级，节点图形提示停留、观察和交流。',
    system:'识别从入口主画面延展到分区导视、地面路径、墙面图形和活动手册。蓝色与黄绿色区分两种路径层级，触觉点阵作为方向提示的辅助线索。展厅主视觉强调停留与交流，导视信息则保持简洁、易扫读。',
    next:'本原创展览概念将空间识别、色彩路径与无障碍方向提示放进同一系统，并以完整展厅与导视场景呈现。',
    visuals:['空间主图','导视系统','分区图形','展览手册'], concept:true
  }
];

const app = document.querySelector('#app');
const query = new URLSearchParams(location.search);
const selected = query.get('case');
const project = projects.find(p=>p.id===selected);
const categories = ['ALL','PERSONAL SYSTEMS','BRAND','EDITORIAL','POSTER','MOTION','3D','CAMPAIGN','SPATIAL'];
const categoryMap = {'PERSONAL SYSTEMS':['aaos','worklab','designlab'],'BRAND':['nocturne'],'EDITORIAL':['field-index'],'POSTER':['tideline'],'MOTION':['kinetic-field'],'3D':['form-study'],'CAMPAIGN':['after-hours'],'SPATIAL':['common-ground']};

function header(){return `<header class="topbar"><a class="wordmark" href="index.html" aria-label="DT ALEX STUDIOS 首页"><span class="mark">DA</span><span>DT ALEX<br><b>STUDIOS</b></span></a><nav><a href="index.html#work">WORK</a><a href="index.html#projects">PROJECTS</a><a href="index.html#about">ABOUT</a></nav><a class="index-link" href="index.html#work">INDEX <span>↗</span></a></header>`}
function footer(){return `<footer class="footer"><span>DT ALEX STUDIOS</span><span>Graphic / Visual Design · Digital Experiments</span><a href="index.html#work">Back to index ↑</a></footer>`}
function card(p){return `<a class="work-card ${p.concept?'is-concept':''}" href="?case=${p.id}" data-category="${p.id}"><div class="card-image"><img src="${p.image}" alt="${p.title} case study banner" loading="lazy"/><span class="card-index">${p.number} / 10</span>${p.concept?'<span class="concept-chip">CONCEPT STUDY</span>':''}</div><div class="card-meta"><div><h3>${p.title}</h3><p>${p.titleCN}</p></div><span class="arrow">↗</span></div><div class="card-tag">${p.disciplines.join(' · ')}</div></a>`}
function home(){document.title='DT ALEX STUDIOS — Selected Work';app.innerHTML=`${header()}<main><section class="intro"><div class="eyebrow">INDEPENDENT DESIGN PRACTICE <span>2026 — ONGOING</span></div><div class="intro-grid"><h1>Design is how<br/>I make sense<br/><i>of things.</i></h1><div class="intro-side"><p>我是 DT Alex，一名平面与视觉设计师。持续在品牌、影像、空间和数字产品之间做设计，也用代码把自己的想法变成项目。</p><a href="#work" class="text-link">EXPLORE SELECTED WORK <span>↓</span></a></div></div><div class="intro-bottom"><span>GRAPHIC / VISUAL DESIGNER</span><span>BRAND · 3D · MOTION · DIGITAL</span><span>SCROLL TO EXPLORE ↓</span></div></section><section class="world-teaser"><div class="world-copy"><span class="eyebrow">PROJECT 00 / THE PORTFOLIO</span><h2>A place for<br/>work in progress.</h2><p>这里收纳完成的设计、长期项目，以及还在生长的实验。先看作品，也可以直接打开索引。</p><a href="#work" class="text-link">OPEN INDEX ↗</a></div><div class="world-art"><div class="orbit orbit-a"></div><div class="orbit orbit-b"></div><span class="orbit-point"></span><span class="world-word">DT<br/>ALEX</span><span class="world-caption">FORM / IMAGE / SYSTEM</span></div></section><section class="work-section" id="work"><div class="section-head"><div><span class="eyebrow">SELECTED WORK / 2026</span><h2>Ten directions.<br/><i>One practice.</i></h2></div><p>三个持续推进的个人系统，和七个用于展示媒介跨度的概念案例。七个原创概念项目覆盖品牌、编辑、海报、动态、产品与空间设计，并在页面中明确标注为自拟项目。</p></div><div class="filter-row" role="group" aria-label="Filter projects">${categories.map((c,i)=>`<button class="filter ${i===0?'active':''}" data-filter="${c}">${c}</button>`).join('')}</div><div class="work-grid" id="workGrid">${projects.map(card).join('')}</div></section><section class="project-band" id="projects"><div><span class="eyebrow">PERSONAL PROJECTS</span><h2>Systems I’m<br/>building along<br/>the way.</h2></div><div class="project-list">${projects.slice(0,3).map(p=>`<a href="?case=${p.id}"><span>${p.number}</span><strong>${p.title}</strong><small>${p.titleCN}</small><b>↗</b></a>`).join('')}</div></section><section class="about-section" id="about"><span class="eyebrow">ABOUT / DT ALEX</span><div class="about-content"><h2>Graphic design<br/>is the starting point.</h2><div><p>我主要做平面与视觉设计，也持续关注品牌、3D、动态影像和数字体验。编程与 AI 是我探索方法、推进个人项目的工具，设计判断仍然回到构图、文字、节奏和细节。</p><p>这里的三个长期项目记录了我如何把设计思考延伸到产品与系统；概念案例则展示不同媒介的视觉方向。</p><a class="text-link" href="mailto:hello@dtalex.studio">SAY HELLO ↗</a></div></div></section></main>${footer()}`;
  document.querySelectorAll('.filter').forEach(btn=>btn.addEventListener('click',()=>{document.querySelector('.filter.active')?.classList.remove('active');btn.classList.add('active');const f=btn.dataset.filter;document.querySelectorAll('.work-card').forEach(el=>{const id=el.dataset.category;el.hidden=f!=='ALL'&&!((categoryMap[f]||[]).includes(id));});}));}
function uiMock(p){const u=p.ui;if(!u)return '';const detail={aaos:['Source notes','Evidence anchors','Review queue'],worklab:['Task packs','Observer · read only','Audit trail'],designlab:['Brief → Direction','Design tokens','Preflight report']}[u.kind];return `<section class="ui-showcase"><div class="ui-intro"><span class="eyebrow">PRODUCT UI / PORTFOLIO VISUALIZATION</span><h2>${u.label}</h2><p>此处以作品集页面内的界面构图展示规划中的核心工作流。它不代表产品当前安装态，也不替代实时仓库验收。</p></div><div class="mock-window ${u.kind}"><div class="mock-bar"><span class="window-dots"><i></i><i></i><i></i></span><span>${u.sub}</span><span class="mock-status">LOCAL · PREVIEW</span></div><div class="mock-body"><aside class="mock-rail"><b class="mini-mark">${u.kind==='aaos'?'◉':u.kind==='worklab'?'⌘':'◫'}</b><i>⌂</i><i>▤</i><i>◇</i><i>◷</i><i>⚙</i></aside><div class="mock-main"><div class="mock-title"><div><small>WORKSPACE / 01</small><h3>${u.sub}</h3></div><button>＋ New</button></div><div class="mock-columns"><div class="mock-panel primary"><div class="panel-head">${detail[0]} <span>↗</span></div><div class="mock-document"><small>UPDATED MOMENTS AGO</small><strong>${p.id==='aaos'?'A note becomes useful when its source stays close.':p.id==='worklab'?'One canonical rule. A clear execution path.':'Research into direction. Direction into a system.'}</strong><p>${p.id==='aaos'?'Original source, human notes and learning events share durable references.':'Keep the action, permission and result visible at every handoff.'}</p><div class="skeleton-line w80"></div><div class="skeleton-line w55"></div></div><div class="source-row"><span class="source-icon">↗</span><div><b>${detail[1]}</b><small>Version-linked reference</small></div><em>OPEN</em></div></div><div class="mock-panel side"><div class="panel-head">${detail[2]} <span>•••</span></div><div class="timeline"><i></i><div><b>Current step</b><small>Saved · review available</small></div></div><div class="progress-track"><span></span></div><div class="mock-note">Status is shown from a defined source. Missing data stays visible.</div><button class="ghost-button">VIEW DETAILS ↗</button></div></div></div></div></div></section>`}
const storyTitles = {"aaos": ["A source should stay<br/><i>within reach.</i>", "Keep learning<br/><i>traceable.</i>", "A workspace for<br/><i>knowledge in motion.</i>", "Save the thread."], "worklab": ["Execution needs<br/><i>clear boundaries.</i>", "Make every handoff<br/><i>inspectable.</i>", "One control plane<br/><i>across agents.</i>", "Observe the work."], "designlab": ["Good design begins<br/><i>with evidence.</i>", "Turn a brief into<br/><i>a working system.</i>", "Research through<br/><i>ready-to-deliver.</i>", "Design with a trail."], "nocturne": ["Let the material<br/><i>hold the silence.</i>", "Build a world<br/><i>around low light.</i>", "One quiet code<br/><i>across every touchpoint.</i>", "Leave room for scent."], "field-index": ["Look closer at<br/><i>the city edge.</i>", "Turn observation<br/><i>into an index.</i>", "A field guide<br/><i>made for wandering.</i>", "Read the city in leaves."], "tideline": ["The tide carries<br/><i>a warning.</i>", "Make the series<br/><i>move as one.</i>", "One visual current<br/><i>across every format.</i>", "Keep the signal visible."], "kinetic-field": ["Give type<br/><i>a physical rhythm.</i>", "Build motion from<br/><i>four clear beats.</i>", "A motion language<br/><i>that holds in stills.</i>", "Let the form move."], "form-study": ["How little structure<br/><i>can support a seat?</i>", "Fold one surface<br/><i>into a frame.</i>", "A study in<br/><i>structure and lightness.</i>", "Form follows the fold."], "after-hours": ["Night can become<br/><i>a shared place.</i>", "Let light guide<br/><i>the whole campaign.</i>", "A clear identity<br/><i>after dark.</i>", "Follow the light."], "common-ground": ["A public room<br/><i>should invite entry.</i>", "Use color to<br/><i>make a path legible.</i>", "One spatial language<br/><i>from entry to gathering.</i>", "Make room for everyone."]};
function detail(p){const story=storyTitles[p.id];document.title=`${p.title} — DT ALEX STUDIOS`;const concept=p.concept;const next=projects[(projects.findIndex(x=>x.id===p.id)+1)%projects.length];app.innerHTML=`${header()}<main class="case-page ${concept?'concept-page':''}"><div class="case-top"><a href="index.html#work" class="back-link">← ALL WORK</a><span>${p.number} / 10</span><span>${concept?'CONCEPT STUDY · FICTIONAL PROJECT':'PERSONAL PROJECT · ONGOING'}</span></div><section class="case-hero"><img src="${p.image}" alt="${p.title} — case study banner"/><div class="hero-shade"></div><div class="case-title"><span class="eyebrow">${p.type} / ${p.year}</span><h1>${p.title}</h1><p>${p.titleCN}</p></div><div class="hero-caption">${p.disciplines.join(' / ')}</div></section>${concept?'<div class="concept-notice"><span>CONCEPT PROJECT</span><p>原创自拟概念项目，包含完整视觉系统与场景应用；非客户委托或商业发布。</p></div>':''}<section class="case-summary"><div><span class="eyebrow">PROJECT OVERVIEW</span><h2>${p.summary}</h2></div><div class="case-spec"><div><small>TYPE</small><b>${p.type}</b></div><div><small>ROLE</small><b>${concept?'Concept / Visual Direction':p.disciplines.slice(0,2).join(' / ')}</b></div><div><small>YEAR</small><b>${p.year}</b></div><div><small>STATUS</small><b>${p.status}</b></div></div></section><section class="story-block"><div class="story-label"><span class="eyebrow">01 / THE BRIEF</span><span>WHY THIS EXISTS</span></div><div class="story-copy"><h2>${story[0]}</h2><p>${p.brief}</p></div></section>${!concept?uiMock(p):''}<section class="story-block alt"><div class="story-label"><span class="eyebrow">02 / THE APPROACH</span><span>DESIGN DECISIONS</span></div><div class="story-copy"><h2>${story[1]}</h2><p>${p.approach}</p><div class="keyword-row">${p.visuals.map((v,i)=>`<span><b>0${i+1}</b>${v}</span>`).join('')}</div></div></section><section class="gallery-grid"><div class="gallery-large"><img src="${p.gallery[0]}" alt="${p.title} — ${p.visuals[0]}" loading="lazy"/><span>01 / ${p.visuals[0]}</span></div><div class="gallery-small"><img src="${p.gallery[1]}" alt="${p.title} — ${p.visuals[1]}" loading="lazy"/><span>02 / ${p.visuals[1]}</span></div></section><section class="story-block"><div class="story-label"><span class="eyebrow">03 / THE SYSTEM</span><span>FROM IMAGE TO USE</span></div><div class="story-copy"><h2>${story[2]}</h2><p>${p.system}</p><div class="deliverable-list"><span>01 <b>${p.visuals[0]}</b></span><span>02 <b>${p.visuals[1]}</b></span><span>03 <b>${p.visuals[2]}</b></span><span>04 <b>${p.visuals[3]}</b></span></div></div></section><section class="case-outro"><span class="eyebrow">04 / WHAT’S NEXT</span><h2>${story[3]}</h2><p>${p.next}</p></section><a href="?case=${next.id}" class="next-case"><span>NEXT PROJECT / ${next.number}</span><strong>${next.title}</strong><b>↗</b></a></main>${footer()}`}
if(project) detail(project); else home();
