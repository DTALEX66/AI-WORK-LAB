# Ten case studies — copy and page plan

Each project page uses a case-specific title, summary, brief, design approach, system explanation, four visual deliverables, gallery captions, and closing statement. Three ongoing personal systems are written from the supplied project plans. Seven other entries are complete self-initiated concept studies, clearly labeled as fictional concepts rather than client work.

## 01 — ArcheAxis Knowledge / 星环知识平台

- **Type / role:** Personal digital product; product design, knowledge system, visual design.
- **Summary:** 本地优先、可追溯的个人知识工作台，让原始资料、个人思考与学习过程持续连在一起。
- **Brief:** 资料、研究、对话和自己的判断散落在不同工具里，时间一久，来源难以找回，学习也很难接着上次继续。
- **Approach:** 设计长期使用的知识工作台。普通内容可先保存、检索与编辑；来源忠实度核验和专业依据分析分别呈现。学习与机器反馈保持可追溯，候选不会自动成为可信事实。
- **System:** 工作台、知识、学习、AI 学习、探索与系统能力组织入口；阅读和编辑是主场景，证据锚点、版本、引用与学习事件按需展开。规划采用 Tauri 2、React/TypeScript/Vite、Rust Core 与 SQLite/CAS 权威数据边界。
- **Images:** Hero; source archive; reading and learning workspace.
- **Status:** Ongoing personal project. Product UI is a portfolio visualization from the blueprint, not a captured live application.

## 02 — WORK-LAB / 工作流实验室

- **Type / role:** Personal digital product; product design, agent systems, observability.
- **Summary:** 客户端中立的 AI Agent 控制平面，把规则、技能与工作流治理收敛到一个规范源。
- **Brief:** 不同 Agent 客户端各自维护规则、技能和记忆，能力容易漂移；从计划到执行、审计和交付也缺少统一视角。
- **Approach:** 控制与治理层负责描述规范，适配层按客户端原生方式投影；任务包串起目标、执行、审批、审计与交付，让每一步都有可检查的边界。
- **System:** 产品视图围绕任务、工作流、执行、只读 Observer、规则策略、集成与审批组织。Observer 只读呈现状态；缺少的数据明确显示 UNKNOWN。高风险外部变更需要独立确认。
- **Images:** Hero; workflow orchestration board; execution trace and audit dashboard.
- **Status:** Ongoing personal project. Page states are illustrative and do not represent live system receipts.

## 03 — DESIGN-LAB / 视觉设计实验室

- **Type / role:** Personal digital product; design intelligence, creative production, quality.
- **Summary:** AI 原生、平台中立的设计生产系统，把研究、设计方法、质量预检与交付连成可回溯流程。
- **Brief:** 参考、生成、排版、修改和导出分布在不同工具中。做过什么判断、为什么选这个方向，常常没能跟作品一起留下来。
- **Approach:** 组织 Research / Evidence → Brief → Direction → DesignSystem → 生产 → Preflight → 交付。版本链保留设计决定；预检只探测并报告，不暗中安装或改变环境。
- **System:** 工作台覆盖项目、研究、品牌系统、设计领域、工具适配、质量预检与交付。它连接宿主工具，不重建画布、聊天客户端、模型网关或 SaaS 后端。证据级别 E0–E5 分开表达。
- **Images:** Hero; creative research board; preflight review interface.
- **Status:** Ongoing personal project. Interface images are portfolio visualizations based on the project plan.

## 04 — NOCTURNE / 气味的留白

- **Type / role:** Original concept brand; identity, packaging, art direction.
- **Summary:** 为一款自拟的独立香氛品牌构想识别与包装，以矿物质感和冷静留白表达夜色。
- **Brief:** 让香气不靠繁复叙事取胜，而像夜间空气一样，靠材质、比例和细节慢慢显现。
- **Approach:** 以烟熏玻璃、岩面和银色弧线建立主视觉母题。瓶身比例保持克制，包装结构强调触感与留白，延展到静物摄影和数字橱窗。
- **System:** 烟熏瓶身承接暗部，银色瓶盖成为唯一高光；包装使用压纹矿物纸与克制的香型编码。静物广告、电商首屏和包装细节共享低照度材质语言。
- **Images:** Hero; packaging still life; smoked glass and mineral material macro.
- **Status:** Complete self-initiated fictional concept; not a client commission or commercial release.

## 05 — FIELD INDEX / 城市植物档案

- **Type / role:** Original concept publication; editorial design, publication, photography.
- **Summary:** 一份关于城市植物如何适应环境的自拟出版物，用田野记录转译成可阅读的视觉档案。
- **Brief:** 植物如何在城市缝隙里生长？如何让观察、地图和图像在纸上形成一条阅读路径？
- **Approach:** 采用编号、网格、局部放大的叶片纹理和地图切片作为编辑线索。跨页留出安静段落，让资料页、图像页与短叙事交替出现。
- **System:** 封面以叶脉切片建立辨识度，内页用跨页标本图建立停留点，地图将采样编号放回街区路径。线上索引沿用同一编号和色彩规则。
- **Images:** Hero; botanical publication spread; layered urban specimen map.
- **Status:** Complete self-initiated fictional editorial concept.

## 06 — TIDELINE / 潮汐仍在

- **Type / role:** Original concept campaign; graphic design, poster, campaign.
- **Summary:** 一组自拟的海洋保护主题海报，以三张画面拼合潮流与鱼形的视觉隐喻。
- **Brief:** 海洋里的安全感如何被一点一点侵蚀？一组海报如何在单张与整体之间切换阅读？
- **Approach:** 以断裂的水纹构成跨幅主图形，局部加入信号红作为警觉点。标题与信息区采用稳定网格，保证系列一致，也让每张独立成立。
- **System:** 三张海报表现涨潮、回流与海面静止。数字裁切保留主图和行动提示；展览墙按阅读顺序布置，从视觉隐喻引向海洋保护主题。
- **Images:** Hero; ocean graphic detail; three-poster series.
- **Status:** Complete self-initiated fictional concept; unrelated to any existing event or brand.

## 07 — KINETIC FIELD / 字形运动研究

- **Type / role:** Original concept motion study; motion design, typography, creative coding.
- **Summary:** 一组自拟动态字形实验，把网格中的字形当作具有重量、速度与阻力的物体。
- **Brief:** 如果字不是贴在画面上的信息，而是受力、碰撞、停顿和释放的对象，阅读节奏会怎样变化？
- **Approach:** 建立固定基线与边距，使用有限色彩区分运动层级。动势由加速、碰撞和回弹组成，静帧仍保留清晰层级。
- **System:** 视觉规则固定基线、边距与两种高亮色，运动由加速、碰撞、回弹和归位四个节拍组成。分镜拆分动作阶段，静帧保持明确重心与方向。
- **Images:** Hero; motion storyboard; kinetic key frame.
- **Status:** Complete self-initiated fictional motion concept, represented through a sequence board and still artwork.

## 08 — FORM STUDY 06 / 折面坐具

- **Type / role:** Original concept object; 3D visualization, product concept, material study.
- **Summary:** 一个自拟家具产品概念，以连续折面、冷金属和深蓝半透明材质探索轻量感。
- **Brief:** 通过单一材料的连续弯折，构成稳定坐面与支撑关系，同时保留视觉上的轻盈。
- **Approach:** 以三分之四视角建立主渲染，配合材料近景、轮廓线和构造拆解图，让结构成为主角。
- **System:** 主视觉展示整体姿态，材质近景强调金属折边与半透明钴蓝坐面，构造视图说明连续折面如何连接座面和支撑。概念表达不宣称工程验证或量产。
- **Images:** Hero; three-quarter product render; folded metal and cobalt material detail.
- **Status:** Complete self-initiated fictional product concept; not engineered or manufactured.

## 09 — AFTER HOURS / 夜行文化计划

- **Type / role:** Original concept campaign; campaign, key visual, art direction.
- **Summary:** 为一场自拟的夜间艺术节构想主视觉与延展物料，用城市光带串联不同的观看场景。
- **Brief:** 夜晚不只是活动时间，它也能成为城市里另一种共同生活的空间。
- **Approach:** 以冷色光带、城市廊道和竖向画幅构成主视觉。红色作为少量节奏标记，延展到海报、社交传播与现场导视。
- **System:** 夜间建筑照片和流动光带构成主 KV；红色几何作为节目切换标记。海报、移动票面与现场屏幕沿用统一网格和标题区。
- **Images:** Hero; poster and ticket family; night arts venue campaign scene.
- **Status:** Complete self-initiated fictional event identity, not a real festival or client commission.

## 10 — COMMON GROUND / 共同场域

- **Type / role:** Original concept exhibition; spatial graphics, exhibition identity, wayfinding.
- **Summary:** 一场自拟的城市公共空间展览，以路径、节点和共享区域构建空间识别系统。
- **Brief:** 展览如何让人从“经过空间”转为“参与空间”，并在建筑内自然找到方向？
- **Approach:** 将地面色带、墙面几何和模块化展具作为同一套导视语言。颜色区分路径层级，节点图形提示停留、观察和交流。
- **System:** 识别从入口主画面延展到分区导视、地面路径、墙面图形和活动手册。蓝色与黄绿色区分路径层级，触觉点阵作为方向提示辅助线索。
- **Images:** Hero; exhibition interior; accessible wayfinding route system.
- **Status:** Complete self-initiated fictional exhibition concept; scene is a design visualization.

## Page model and asset map

Each case page has one unique hero banner and two unique gallery artworks. The home grid links directly to ten independently addressable pages via `?case=<id>`. Narrative and gallery captions are tailored to the case. UI compositions on the first three pages are explicitly described as portfolio visualizations based on the current project plans.
